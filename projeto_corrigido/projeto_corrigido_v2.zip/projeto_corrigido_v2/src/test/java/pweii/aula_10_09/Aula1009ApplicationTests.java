package pweii.aula_10_09;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula1009ApplicationTests {

	@Test
	void contextLoads() {
	}

}
