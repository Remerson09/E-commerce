package pweii.aula_10_09.model.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.LogoutConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration {

    @Autowired
    UsuarioDetailsConfig usuarioDetailsConfig;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // Desativa CSRF para evitar o erro do "parameterName" que vimos no seu log
                .csrf(csrf -> csrf.disable())
                .csrf(withDefaults())
                .authorizeHttpRequests(customizer -> customizer
                        // 1. Permite acesso à página de login e recursos estáticos
                        .requestMatchers("/login", "/css/**", "/js/**", "/images/**").permitAll()

                        // 2. Cadastro de pessoa física e jurídica aberto para novos usuários (formulários e salvamento)
                        .requestMatchers("/pessoa/formPF", "/pessoa/formPJ", "/pessoa/savePF", "/pessoa/savePJ").permitAll()

                        // 3. Permite que todos vejam produtos e o carrinho
                        .requestMatchers("/produto/list", "/vendas/carrinho", "/produto/adicionar/**").permitAll()

                        // 4. Apenas ADMIN vê a lista de pessoas, deleta/edita e vê todas as vendas
                        .requestMatchers("/pessoa/list", "/pessoa/remove/**", "/pessoa/edit/**").hasRole("ADMIN")

                        // 5. Finalizar venda e ver suas próprias vendas exige login
                        .requestMatchers("/vendas/finalizar", "/vendas/list", "/vendas/detalhe/**").authenticated()

                        // 5. Qualquer outra rota exige autenticação
                        .anyRequest().authenticated()
                )
                .formLogin(customizer -> customizer
                        .loginPage("/login")
                        .defaultSuccessUrl("/produto/list", true)
                        .permitAll()
                )
                .httpBasic(withDefaults())
                .logout(LogoutConfigurer::permitAll)
                .rememberMe(withDefaults());

        return http.build();
    }

    // Vincula o seu UsuarioDetailsConfig ao sistema de autenticação
    @Autowired
    public void configureUserDetails(final AuthenticationManagerBuilder builder) throws Exception {
        builder.userDetailsService(usuarioDetailsConfig).passwordEncoder(new BCryptPasswordEncoder());
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}