package pweii.aula_10_09.model.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.LogoutConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration {

    @Autowired
    UsuarioDetailsConfig usuarioDetailsConfig;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // Desativa CSRF para evitar o erro do "parameterName" que vimos no seu log
                .csrf(csrf -> csrf.disable())
                .csrf(withDefaults())
                .authorizeHttpRequests(customizer -> customizer
                        // 1. Permite acesso à página de login e recursos estáticos
                        .requestMatchers("/login", "/css/**", "/js/**", "/images/**").permitAll()

                        // 2. IMPORTANTE: Permite que QUALQUER UM envie o formulário de cadastro (POST)
                        // Adapte a URL conforme o seu Controller de Pessoa
                        .requestMatchers(HttpMethod.POST, "/pessoa/save").permitAll()
                        .requestMatchers(HttpMethod.POST, "/pessoa/savePJ").permitAll()

                        // 3. Apenas ADMIN vê a lista de pessoas e deleta/edita
                        .requestMatchers("/pessoa/list").hasRole("ADMIN")
                        .requestMatchers("/pessoa/remove/**", "/pessoa/edit/**").hasRole("ADMIN")

                        // 4. Usuários Logados (USER e ADMIN) acessam o e-commerce
                        .requestMatchers(
                                "/produto/list",
                                "/vendas/carrinho",
                                "/vendas/finalizar",
                                "/pessoa/formPF",
                                "/pessoa/formPJ"
                        ).hasAnyRole("USER", "ADMIN")

                        // 5. Qualquer outra rota exige autenticação
                        .anyRequest().authenticated()
                )
                .formLogin(customizer -> customizer
                        .loginPage("/login")
                        .defaultSuccessUrl("/produto/list", true)
                        .permitAll()
                )
                .httpBasic(withDefaults())
                .logout(LogoutConfigurer::permitAll)
                .rememberMe(withDefaults());

        return http.build();
    }

    // Vincula o seu UsuarioDetailsConfig ao sistema de autenticação
    @Autowired
    public void configureUserDetails(final AuthenticationManagerBuilder builder) throws Exception {
        builder.userDetailsService(usuarioDetailsConfig).passwordEncoder(new BCryptPasswordEncoder());
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}