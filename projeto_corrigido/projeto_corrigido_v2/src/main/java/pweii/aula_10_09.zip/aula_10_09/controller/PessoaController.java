package pweii.aula_10_09.controller;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pweii.aula_10_09.model.entity.Pessoa;
import pweii.aula_10_09.model.entity.PessoaFisica;
import pweii.aula_10_09.model.entity.PessoaJuridica;
import pweii.aula_10_09.model.repository.PessoaRepository;

import java.util.List;

@Transactional
@Controller
@RequestMapping("/pessoa")
public class PessoaController {

    @Autowired
    PessoaRepository pessoaRepository;

    @ModelAttribute
    public void addAttributes(ModelMap model) {
        if (!model.containsAttribute("pessoaFisica")) {
            model.addAttribute("pessoaFisica", new PessoaFisica());
        }
        if (!model.containsAttribute("pessoaJuridica")) {
            model.addAttribute("pessoaJuridica", new PessoaJuridica());
        }
    }
    @GetMapping("/formPF")
    public String formPF(ModelMap model) {
        model.addAttribute("tipoPessoa", "PF");
        return "pessoa/form";
    }

    @GetMapping("/formPJ")
    public String formPJ(ModelMap model) {
        model.addAttribute("tipoPessoa", "PJ");
        return "pessoa/form";
    }

    @GetMapping("/edit/{id}")
    public ModelAndView edit(@PathVariable("id") Long id, ModelMap model) {
        // Usamos findById().orElse() para evitar falha se o ID não existir
        Pessoa pessoa = pessoaRepository.findById(id).orElse(null);

        if (pessoa == null) {
            // Opcional: lidar com pessoa não encontrada
            return new ModelAndView("redirect:/pessoa/list");
        }

        if (pessoa instanceof PessoaFisica) {
            model.addAttribute("pessoaFisica", (PessoaFisica) pessoa);
            model.addAttribute("tipoPessoa", "PF");
        } else {
            model.addAttribute("pessoaJuridica", (PessoaJuridica) pessoa);
            model.addAttribute("tipoPessoa", "PJ");
        }

        return new ModelAndView("pessoa/form", model);
    }

    // Adicione o @Valid antes da entidade e o BindingResult depois dela.
    @PostMapping("/savePF")
    public ModelAndView savePF(@Valid PessoaFisica pessoaFisica, BindingResult result, RedirectAttributes attr) {

        // 1. Limpeza do CPF
        if (pessoaFisica.getCpf() != null) {
            String cpfLimpo = pessoaFisica.getCpf().replaceAll("[^0-9]", "");
            pessoaFisica.setCpf(cpfLimpo);
        }

        // 2. Verificação de Erros
        if (result.hasErrors()) {
            // CORREÇÃO: Aponta para a pasta pessoa e o arquivo form.html
            ModelAndView mv = new ModelAndView("pessoa/form");

            // Importante: Adicione o tipoPessoa para o formulário saber que é PF
            mv.addObject("tipoPessoa", "PF");
            return mv;
        }

        // 3. Salvamento
        pessoaRepository.save(pessoaFisica);

        // 4. Sucesso
        attr.addFlashAttribute("success", "Pessoa Física salva com sucesso!");
        return new ModelAndView("redirect:/pessoa/list");
    }

    @PostMapping("/savePJ")
    public ModelAndView savePJ(PessoaJuridica pessoaJuridica, RedirectAttributes attr) {
        pessoaRepository.save(pessoaJuridica);
        attr.addFlashAttribute("success", "Pessoa Jurídica salva com sucesso!");
        return new ModelAndView("redirect:/pessoa/list");
    }

    @PostMapping("/updatePF")

    public ModelAndView updatePF(@Valid PessoaFisica pessoaFisica, BindingResult result, RedirectAttributes attr) {


        if (pessoaFisica.getCpf() != null) {
            String cpfLimpo = pessoaFisica.getCpf().replaceAll("[^0-9]", "");
            pessoaFisica.setCpf(cpfLimpo);
        }

        if (result.hasErrors()) {
            attr.addFlashAttribute("pessoaFisica", pessoaFisica);

            String mensagemErro = "Erro de validação! Corrija os campos e tente novamente.";
            if (result.hasFieldErrors("cpf")) {
                mensagemErro = "CPF inválido.";
            }
            attr.addFlashAttribute("error", mensagemErro);

            // Retorna para o formulário de edição (com o ID para manter o contexto)
            return new ModelAndView("redirect:/pessoa/edit/" + pessoaFisica.getId());
        }

        pessoaRepository.save(pessoaFisica);
        attr.addFlashAttribute("success", "Pessoa Física atualizada com sucesso!");
        return new ModelAndView("redirect:/pessoa/list");
    }

    @PostMapping("/updatePJ")
    public ModelAndView updatePJ(PessoaJuridica pessoaJuridica, RedirectAttributes attr) {
        pessoaRepository.save(pessoaJuridica);
        attr.addFlashAttribute("success", "Pessoa Jurídica atualizada com sucesso!");
        return new ModelAndView("redirect:/pessoa/list");
    }

    @GetMapping({"/list", "/filter"})
    public ModelAndView listarOuFiltrar(@RequestParam(value = "nome", required = false) String nome,
                                        ModelMap model) {
        List<Pessoa> pessoas;
        if (nome != null && !nome.trim().isEmpty()) {
            String termoBusca = "%" + nome.trim() + "%";
            pessoas = pessoaRepository.findByNomeOrRazaoSocialContaining(termoBusca);
            model.addAttribute("nome", nome);
        } else {
            // Se não houver filtro, lista todos (método list padrão)
            pessoas = pessoaRepository.findAll();
            model.addAttribute("nome", ""); // Garante que o campo de filtro esteja vazio
        }

        model.addAttribute("pessoas", pessoas);
        return new ModelAndView("pessoa/list", model);
    }

    @GetMapping("/remove/{id}")
    public ModelAndView remove(@PathVariable("id") Long id, RedirectAttributes attr) {
        pessoaRepository.deleteById(id);
        attr.addFlashAttribute("info", "Cliente excluído com sucesso!");
        return new ModelAndView("redirect:/pessoa/list");
    }

    @GetMapping("/vendas/{id}")
    public ModelAndView vendasCliente(@PathVariable("id") Long id, ModelMap model) {
        Pessoa cliente = pessoaRepository.findById(id).orElseThrow(() -> new RuntimeException("Cliente não encontrado"));
        model.addAttribute("cliente", cliente);
        // Assumindo que o campo 'vendas' na entidade Pessoa é carregado corretamente
        model.addAttribute("vendas", cliente.getVendas());
        return new ModelAndView("pessoa/vendas", model);
    }
}