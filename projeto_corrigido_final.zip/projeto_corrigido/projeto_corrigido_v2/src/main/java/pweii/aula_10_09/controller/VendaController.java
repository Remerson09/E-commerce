package pweii.aula_10_09.controller;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

// 💡 CORRIGIDO: Importação do CarrinhoServece do seu pacote 'servece'
import pweii.aula_10_09.servece.CarrinhoServece;
// 💡 Assumindo que ItemCarrinho de Session está no pacote service, não entity
import pweii.aula_10_09.model.entity.Venda;
import pweii.aula_10_09.model.entity.ItemVenda;
import pweii.aula_10_09.model.repository.VendaRepository;
import pweii.aula_10_09.model.repository.PessoaRepository;
// 💡 CORRIGIDO: Assumindo que o ItemCarrinho está na camada de entidade/modelo
import pweii.aula_10_09.model.entity.ItemCarrinho;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Transactional
@Controller
@RequestMapping("/vendas")
public class VendaController {

    @Autowired
    VendaRepository vendaRepository;

    @Autowired
    PessoaRepository pessoaRepository;

    // 💡 CORRIGIDO: Injeta a classe com o nome exato: CarrinhoServece
    @Autowired
    CarrinhoServece carrinhoService;

    @GetMapping("/form")
    public ModelAndView form() {
        // Redireciona para a lista de produtos (onde a compra é iniciada)
        return new ModelAndView("redirect:/produto/list");
    }

    @GetMapping("/list")
    public ModelAndView listar(ModelMap model) {
        // Carrega todas as vendas
        model.addAttribute("vendas", vendaRepository.findAll());
        return new ModelAndView("vendas/list", model);
    }

    @GetMapping("/remove/{id}")
    public ModelAndView remove(@PathVariable("id") Long id) {
        vendaRepository.deleteById(id);
        return new ModelAndView("redirect:/vendas/list");
    }

    @GetMapping("/detalhe/{id}")
    public ModelAndView details(@PathVariable("id") Long id, ModelMap model) {
        model.addAttribute("venda", vendaRepository.findById(id).get());
        return new ModelAndView("vendas/detalhe", model);
    }

    /**
     * 💡 Endpoint de FINALIZAÇÃO DA VENDA
     * Converte os itens da Sessão (CarrinhoService) em Entidades de Persistência (Venda/ItemVenda).
     */
    // @PostMapping("/finalizar") // Removido para evitar conflito com CarrinhoController
    public ModelAndView finalizarVenda(@RequestParam("clienteId") Long clienteId,
                                       @RequestParam("descricao") String descricao,
                                       ModelMap model) {

        // 💡 CORRIGIDO: O tipo da lista deve ser ItemCarrinho (importado de model.entity)
        List<ItemCarrinho> itensCarrinho = carrinhoService.getItens();

        if (itensCarrinho.isEmpty()) {
            return new ModelAndView("redirect:/carrinho/view?erro=vazio");
        }

        // 1. Cria a Venda e associa o Cliente
        Venda venda = new Venda();
        venda.setDataVenda(LocalDateTime.now());
        venda.setDescricao(descricao);
        venda.setCliente(pessoaRepository.findById(clienteId).orElseThrow(() -> new RuntimeException("Cliente não encontrado")));

        // 2. Transfere os Itens do Carrinho (Sessão) para a Venda (DB)
        List<ItemVenda> itensVenda = new ArrayList<>();

        // 💡 CORRIGIDO: O tipo da variável de iteração deve ser ItemCarrinho
        for (ItemCarrinho itemCarrinho : itensCarrinho) {
            ItemVenda itemVenda = new ItemVenda();

            itemVenda.setVenda(venda);
            itemVenda.setProduto(itemCarrinho.getProduto());

            // Converte Integer do ItemCarrinho para Double do ItemVenda
            itemVenda.setQuantidade(itemCarrinho.getQuantidade().doubleValue());

            // Define o preço histórico (para auditoria)
            itemVenda.setPrecoUnitario(itemCarrinho.getProduto().getValor());

            itensVenda.add(itemVenda);
        }

        venda.setItens(itensVenda);

        // 3. Salva a Venda (o Cascade salva os ItemVenda)
        vendaRepository.save(venda);

        // 4. Limpa o Carrinho após a Finalização
        carrinhoService.limpar();

        return new ModelAndView("redirect:/vendas/list");
    }
}