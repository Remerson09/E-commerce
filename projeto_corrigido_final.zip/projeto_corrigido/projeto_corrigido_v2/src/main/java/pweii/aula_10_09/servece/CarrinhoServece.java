package pweii.aula_10_09.servece;

import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.SessionScope;
import pweii.aula_10_09.model.entity.Produto;
// Note que ItemCarrinho deve ser importado corretamente do pacote onde ele está
import pweii.aula_10_09.model.entity.ItemCarrinho; // Assumindo que ItemCarrinho está em model.entity

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
@SessionScope // CRÍTICO: Garante uma instância do carrinho por sessão do usuário
public class CarrinhoServece { // Usando 'Servece' conforme sua estrutura

    // Map para armazenar os itens, usando o ID do Produto como chave. LinkedHashMap mantém a ordem.
    // Usamos o ItemCarrinho do pacote model.entity
    private final Map<Long, ItemCarrinho> itens = new LinkedHashMap<>();

    /**
     * Adiciona ou incrementa a quantidade de um produto no carrinho.
     * @param produto O produto a ser adicionado.
     * @param quantidade A quantidade a ser somada.
     */
    public void adicionar(Produto produto, int quantidade) {
        if (produto == null || quantidade <= 0) return;

        // Tenta pegar o item existente ou cria um novo
        ItemCarrinho item = itens.getOrDefault(produto.getId(), new ItemCarrinho(produto, 0));

        // Soma a nova quantidade
        item.setQuantidade(item.getQuantidade() + quantidade);

        if (item.getQuantidade() <= 0) {
            remover(produto.getId());
        } else {
            itens.put(produto.getId(), item);
        }
    }

    /**
     * Define uma nova quantidade exata para um item no carrinho.
     * @param produtoId ID do produto.
     * @param novaQuantidade Nova quantidade.
     */
    public void atualizarQuantidade(Long produtoId, int novaQuantidade) {
        if (novaQuantidade <= 0) {
            remover(produtoId);
            return;
        }
        ItemCarrinho item = itens.get(produtoId);
        if (item != null) {
            item.setQuantidade(novaQuantidade);
        }
    }

    /**
     * Remove um produto do carrinho.
     * @param produtoId ID do produto a ser removido.
     */
    public void remover(Long produtoId) {
        itens.remove(produtoId);
    }

    /**
     * Retorna a lista de itens no carrinho.
     */
    public List<ItemCarrinho> getItens() {
        return new ArrayList<>(itens.values());
    }

    /**
     * Calcula o valor total de todos os itens no carrinho.
     */
    public BigDecimal getTotal() {
        return itens.values().stream()
                // Chama o getSubtotal que calcula (preço * quantidade)
                .map(ItemCarrinho::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Retorna o número total de unidades no carrinho.
     */
    public int getQuantidadeItens() {
        return itens.values().stream().mapToInt(ItemCarrinho::getQuantidade).sum();
    }

    /**
     * Esvazia o carrinho. Chamado após a finalização da venda.
     */
    public void limpar() {
        itens.clear();
    }
}