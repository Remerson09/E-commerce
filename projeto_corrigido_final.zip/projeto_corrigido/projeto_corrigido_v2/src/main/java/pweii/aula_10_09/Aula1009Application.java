package pweii.aula_10_09;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula1009Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula1009Application.class, args);
	}

}
