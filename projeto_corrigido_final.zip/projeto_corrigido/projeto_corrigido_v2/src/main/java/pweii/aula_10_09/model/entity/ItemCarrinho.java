package pweii.aula_10_09.model.entity;

import lombok.*;
import pweii.aula_10_09.model.entity.Produto;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ItemCarrinho {

    private Produto produto;
    private Integer quantidade; // Usamos Integer para praticidade no carrinho

    /**
     * Calcula o subtotal deste item do carrinho.
     * @return BigDecimal: preco * quantidade
     */
    public BigDecimal getSubtotal() {
        if (produto == null || produto.getValor() == null || quantidade == null) {
            return BigDecimal.ZERO;
        }
        // Multiplica o valor do Produto pelo Integer quantidade
        return produto.getValor().multiply(BigDecimal.valueOf(quantidade));
    }
}