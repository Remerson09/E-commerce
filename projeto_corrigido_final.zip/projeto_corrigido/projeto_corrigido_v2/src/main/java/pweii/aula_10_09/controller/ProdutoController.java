package pweii.aula_10_09.controller;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pweii.aula_10_09.model.entity.Produto;
import pweii.aula_10_09.model.repository.ProdutoRepository;
import pweii.aula_10_09.servece.CarrinhoServece; // 💡 Adicionado para o fluxo de vendas

@Transactional
@Controller
@RequestMapping("/produto")
public class ProdutoController {

    @Autowired
    ProdutoRepository produtoRepository;

    @Autowired // 💡 Injeção necessária para adicionar itens ao carrinho
    CarrinhoServece carrinhoService;

    // ------------------------------------------------
    // CRIAÇÃO E EDIÇÃO (GET)
    // ------------------------------------------------

    @GetMapping("/form")
    public String form(Produto produto){
        return "produto/form";
    }

    @GetMapping("/edit/{id}")
    public ModelAndView edit(@PathVariable("id") Long id, ModelMap model) {
        // Padrão Spring Data: findById()
        Produto produto = produtoRepository.findById(id).orElse(null);
        model.addAttribute("produto", produto);
        return new ModelAndView("produto/form", model);
    }

    // ------------------------------------------------
    // SALVAR/ATUALIZAR (POST UNIFICADO)
    // ------------------------------------------------

    @PostMapping({"/save", "/update"}) // Unifica POSTs de save e update
    public ModelAndView save(Produto produto, RedirectAttributes attr){

        // Padrão Spring Data: save() lida com inserção (ID nulo) e atualização (ID preenchido)
        produtoRepository.save(produto);
        attr.addFlashAttribute("success", "Produto salvo/atualizado com sucesso!");
        return new ModelAndView("redirect:/produto/list");
    }

    // ------------------------------------------------
    // LISTAGEM E REMOÇÃO (CRUD)
    // ------------------------------------------------

    @GetMapping("/list")
    public ModelAndView listar(ModelMap model) {
        // Padrão Spring Data: findAll()
        model.addAttribute("produtos", produtoRepository.findAll());
        // Adiciona o serviço do carrinho ao modelo para acesso na view (para o contador)
        model.addAttribute("carrinhoService", carrinhoService);
        return new ModelAndView("produto/list", model);
    }

    @GetMapping("/remove/{id}")
    public ModelAndView remove(@PathVariable("id") Long id, RedirectAttributes attr){
        // Padrão Spring Data: deleteById()
        produtoRepository.deleteById(id);
        attr.addFlashAttribute("success", "Produto removido com sucesso!");
        return new ModelAndView("redirect:/produto/list");
    }

    // ------------------------------------------------
    // 🛒 ADICIONAR AO CARRINHO (Ação de Compra)
    // ------------------------------------------------

    @PostMapping("/adicionar/{id}")
    public ModelAndView adicionarAoCarrinho(@PathVariable("id") Long produtoId,
                                            @RequestParam("quantidade") int quantidade,
                                            RedirectAttributes attr) {

        Produto produto = produtoRepository.findById(produtoId).orElse(null);

        if (produto == null || quantidade <= 0) {
            attr.addFlashAttribute("error", "Erro ao adicionar produto ou quantidade inválida.");
        } else {
            carrinhoService.adicionar(produto, quantidade);
            attr.addFlashAttribute("success", produto.getDescricao() + " adicionado ao carrinho!");
        }

        return new ModelAndView("redirect:/produto/list");
    }
}