package pweii.aula_10_09.controller;

import jakarta.transaction.Transactional; // 💡 Necessário para persistência
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pweii.aula_10_09.model.entity.ItemVenda; // Importa a Entidade ItemVenda
import pweii.aula_10_09.model.entity.Pessoa;
import pweii.aula_10_09.model.entity.Venda;
import pweii.aula_10_09.model.entity.ItemCarrinho; // Assumindo este import
import pweii.aula_10_09.model.repository.PessoaRepository;
import pweii.aula_10_09.model.repository.VendaRepository; // 💡 INJEÇÃO DIRETA
// Se você tiver um ItemVendaRepository, injete-o aqui:
// import pweii.aula_10_09.model.repository.ItemVendaRepository;
import pweii.aula_10_09.servece.CarrinhoServece;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Transactional // 💡 Transação necessária para salvar Venda e Itens
@Controller
@RequestMapping("/carrinho")
public class CarrinhoController {

    @Autowired
    private CarrinhoServece carrinhoService;

    @Autowired
    private PessoaRepository pessoaRepository;

    @Autowired
    private VendaRepository vendaRepository; // 💡 NOVO: Injeção direta

    // ------------------------------------------------
    // VISUALIZAÇÃO E GERENCIAMENTO (VIEW, ATUALIZAR, REMOVER)
    // ------------------------------------------------

    @GetMapping("/view")
    public ModelAndView visualizar(ModelMap model) {
        model.addAttribute("itens", carrinhoService.getItens());
        model.addAttribute("totalGeral", carrinhoService.getTotal());
        model.addAttribute("clientes", pessoaRepository.findAll());
        return new ModelAndView("carrinho/view", model);
    }

    // ... (Os métodos /atualizar/{id} e /remover/{id} permanecem iguais) ...
    @PostMapping("/atualizar/{id}")
    public ModelAndView atualizar(@PathVariable("id") Long produtoId,
                                  @RequestParam("quantidade") Integer quantidade,
                                  RedirectAttributes attr) {
        carrinhoService.atualizarQuantidade(produtoId, quantidade);
        attr.addFlashAttribute("success", "Quantidade atualizada.");
        return new ModelAndView("redirect:/carrinho/view");
    }

    @GetMapping("/remover/{id}")
    public ModelAndView remover(@PathVariable("id") Long produtoId,
                                RedirectAttributes attr) {
        carrinhoService.remover(produtoId);
        attr.addFlashAttribute("info", "Item removido do carrinho.");
        return new ModelAndView("redirect:/carrinho/view");
    }

    // ------------------------------------------------
    // 💰 FINALIZAR VENDA (Lógica consolidada)
    // ------------------------------------------------

    @PostMapping("/finalizar")
    public ModelAndView finalizarVenda(@RequestParam("clienteId") Long clienteId,
                                       RedirectAttributes attr) {

        List<ItemCarrinho> itensCarrinho = carrinhoService.getItens();

        if (itensCarrinho.isEmpty()) {
            attr.addFlashAttribute("error", "O carrinho está vazio.");
            return new ModelAndView("redirect:/produto/list");
        }

        Pessoa cliente = pessoaRepository.findById(clienteId).orElse(null);
        if (cliente == null) {
            attr.addFlashAttribute("error", "Cliente não encontrado.");
            return new ModelAndView("redirect:/carrinho/view");
        }

        // --- 1. Criar a Venda (Header) ---
        Venda venda = new Venda();
        venda.setCliente(cliente);
        venda.setDataVenda(LocalDateTime.now());
        venda.setDescricao("Venda realizada via Carrinho.");

        // --- 2. Criar e associar os ItemVenda (Detalhes) ---
        List<ItemVenda> itensVenda = itensCarrinho.stream().map(itemCarrinho -> {
            ItemVenda itemVenda = new ItemVenda();
            itemVenda.setVenda(venda); // Associa o item à venda
            itemVenda.setProduto(itemCarrinho.getProduto());
            // Conversão de Integer para Double conforme sua entidade ItemVenda
            itemVenda.setQuantidade(itemCarrinho.getQuantidade().doubleValue());
            // Registra o preço ATUAL do produto
            itemVenda.setPrecoUnitario(itemCarrinho.getProduto().getValor());
            return itemVenda;
        }).collect(Collectors.toList());

        venda.setItens(itensVenda);

        // --- 3. Salvar no Banco ---
        // Se a Venda tiver CascadeType.ALL nos itens, salvar a Venda salva tudo.
        vendaRepository.save(venda);

        // --- 4. Limpar e Redirecionar ---
        carrinhoService.limpar();
        attr.addFlashAttribute("success", "Venda finalizada com sucesso!");
        return new ModelAndView("redirect:/vendas/list");
    }
}